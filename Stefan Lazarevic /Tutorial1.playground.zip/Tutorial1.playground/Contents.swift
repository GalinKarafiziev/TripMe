import UIKit
//intro
var str = "Hello, playground"
print("Hello, Swift Apprentice reader!")
//arithmetics
2 + 6
10 - 2
2 * 4
24 / 3
22 / 7
22.0 / 7.0
28 % 10
(28.0).truncatingRemainder(dividingBy: 10.0)
1 << 3
32 >> 2
((8000 / (5 * 10)) - 32) >> (29 % 5)
350 / 5 + 2
350/(5+2)
//math functions
sin(45 * Double.pi / 180)
// 0.7071067811865475

cos(135 * Double.pi / 180)
// -0.7071067811865475
(2.0).squareRoot() // Same as sqrt(2)
// 1.414213562373095
sqrt(2)
max(7, 1313)
min(2, -2)

max(sqrt(2), Double.pi / 2)
// 1.570796326794897
let number: Int = 10
var numberVar: Int = 45
numberVar=30
var 🐶💩: Int = -1

